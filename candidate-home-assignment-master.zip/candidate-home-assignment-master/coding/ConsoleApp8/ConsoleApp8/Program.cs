﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Xml;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace ConsoleApp8
{

    class Program
    {
        static void Main(string[] args)
        {
            Test t = new Test();
            t.ParseFile(args);
        }



    }
    class Test
    {
        List<Data> content = new List<Data>();
        const string yaml = "yaml";
        const string csv = "CSV";
        const string json = "json";

        public void ParseFile(string[] array)
        {
            foreach (string s in array)
            {
                try
                {
                    if (File.Exists(s))
                    {
                        string fileType = Path.GetExtension(s);
                        switch (fileType.ToLower())
                        {
                            case yaml:
                                ParseYaml(s);
                                break;

                            case json:
                                ParseJson(s);
                                break;
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.Write(e.Message);

                }
            }
        }

        public void ParseJson(string file)

        {
            var details = JsonConvert.DeserializeObject<Data>(file);
        }

        public void ParseYaml(string file)

        {
           
        }


    }
}