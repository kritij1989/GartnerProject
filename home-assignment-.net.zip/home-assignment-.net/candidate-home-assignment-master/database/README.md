# SQL Test Assignment

Attached is a mysqldump of a database to be used during the test.

Below are the questions for this test. Please enter a full, complete, working SQL statement under each question. We do not want the answer to the question. We want the SQL command to derive the answer. We will copy/paste these commands to test the validity of the answer.

**Example:**

_Q. Select all users_

- Please return at least first_name and last_name

SELECT first_name, last_name FROM users;


------

**— Test Starts Here —**

1. Select users whose id is either 3,2 or 4
- select * from users where Id in (3,2,4)

2. Count how many basic and premium listings each active user has

with Listing1(user_id,basic,premium) as
(select  user_id,basic= case
 when listings.status=2 then  1 end ,
 premium=case when listings.status=3 then 1 end
 from listings join users on users.id=listings.user_id where users.status=2
 ),
 Listig2 (user_id,basic,premium) as
 (select user_id,COUNT(Basic) as basic,count(premium) as premium from Listing1  where user_id >0 group by user_id)

 select first_name,last_name,basic,premium from users join Listig2 on users.id=Listig2.user_id

 

3. Show the same count as before but only if they have at least ONE premium listing

with Listing1(user_id,basic,premium) as
(select  user_id,basic= case
 when listings.status=2 then  1 end ,
 premium=case when listings.status=3 then 1 end
 from listings join users on users.id=listings.user_id where users.status=2
 ),
 Listig2 (user_id,basic,premium) as
 (select user_id,COUNT(Basic) as basic,count(premium) as premium from Listing1  where user_id >0 group by user_id)

 select  first_name,last_name,basic,premium from users join Listig2 on users.id=Listig2.user_id
 where premium>0



4. How much revenue has each active vendor made in 2013

with list(userid,currency,revenue)as
(select  user_id,currency,sum(price)
  from users join listings on users.id=listings.user_id join clicks on
clicks.listing_id=listings.id  where users.status=2 and year(clicks.created)='2013' group by user_id,currency  )
select first_name,last_name,currency,revenue from users join list on users.id=list.userid

5. Insert a new click for listing id 3, at $4.00
insert into clicks(listing_id,price,currency,created) values(3,4.00,'USD',GETDATE())
select @@IDENTITY as id


6. Show listings that have not received a click in 2013

select name from clicks join listings on clicks.listing_id=listings.id where year(clicks.created) <> '2013' 
except
select name from clicks join listings on clicks.listing_id=listings.id where year(clicks.created) = '2013' 


7. For each year show number of listings clicked and number of vendors who owned these listings

with temp(clickid,listid,userid,y) as
(select clicks.id as clickid,clicks.listing_id as listingid,users.id as userid,year(clicks.created) as y
 from clicks join listings on clicks.listing_id=listings.id join users on users.id=listings.user_id)
 select count(listid) as listid,userid ,y from temp group by y,userid


8. Return a comma separated string of listing names for all active vendors
- Please return at least: first_name, last_name, listing_names